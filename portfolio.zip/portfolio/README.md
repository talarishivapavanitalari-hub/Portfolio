# Talari Shiva Pavani - Portfolio

Static site (HTML, CSS, JavaScript). No build step.

## Project structure
    index.html
    css/style.css
    js/script.js          navigation + resume check
    js/certificates.js    certificate list (edit this to add certificates)
    assets/profile.jpg            (add your photo)
    assets/Talari_Shiva_Pavani_Resume.pdf   (add your resume)
    assets/certificates/          certificate images

## Add a certificate
1. Save the image (JPG or PNG, under ~500 KB) in `assets/certificates/`.
2. Open `js/certificates.js` and copy the existing block inside `CERTIFICATES`, then change title, issuer, image path and alt text.
3. Refresh the page.

## Run locally
Open a terminal in this folder and run `python -m http.server 8000`, then visit http://localhost:8000

## Push to GitHub
1. Create an empty repository on github.com (for example `portfolio`), with no README.
2. In this folder run:

       git init
       git add .
       git commit -m "Add portfolio website"
       git branch -M main
       git remote add origin https://github.com/talarishivapavanitalari-hub/portfolio.git
       git push -u origin main

Later updates: `git add .` then `git commit -m "Update"` then `git push`.

## Deploy
Vercel: Add New > Project > import the repository > Framework Preset "Other" > Deploy.
Or GitHub Pages: repository Settings > Pages > Deploy from branch `main` / root.
