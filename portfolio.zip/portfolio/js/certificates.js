// ADD NEW CERTIFICATES HERE: copy one block, put the image in assets/certificates/
var CERTIFICATES = [
  {
    title: "Completion Certificate: WE-Engage – FLINT Program (Cohort 4, 2025)",
    issuer: "WE Hub Foundation with the Australian Consulate-General, Bengaluru",
    image: "assets/certificates/we-hub-flint-2025.jpg",
    alt: "Completion certificate for Talari Shiva Pavani from the WE-Engage FLINT Program, Cohort 4, 2025"
  }
  // , { title: "...", issuer: "...", image: "assets/certificates/your-file.jpg", alt: "..." }
];

(function () {
  var list = document.getElementById('cert-list');
  var dlg = document.getElementById('cert-dialog');
  if (!list || !dlg) return;

  CERTIFICATES.forEach(function (c) {
    var card = document.createElement('article');
    card.className = 'card cert';
    var btn = document.createElement('button');
    btn.className = 'cert-thumb';
    btn.setAttribute('aria-label', 'View certificate: ' + c.title);
    var img = document.createElement('img');
    img.src = c.image; img.alt = c.alt || c.title; img.loading = 'lazy';
    btn.appendChild(img);
    var h = document.createElement('h3'); h.textContent = c.title;
    var p = document.createElement('p'); p.className = 'meta'; p.textContent = 'Issued by ' + c.issuer;
    card.appendChild(btn); card.appendChild(h); card.appendChild(p);
    list.appendChild(card);
    btn.addEventListener('click', function () {
      document.getElementById('cert-full').src = c.image;
      document.getElementById('cert-full').alt = c.alt || c.title;
      document.getElementById('cert-caption').textContent = c.title;
      dlg.showModal();
    });
  });

  document.getElementById('cert-close').addEventListener('click', function () { dlg.close(); });
  dlg.addEventListener('click', function (e) { if (e.target === dlg) dlg.close(); });
})();
